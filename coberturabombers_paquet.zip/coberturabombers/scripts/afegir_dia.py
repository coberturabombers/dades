#!/usr/bin/env python3
"""
afegir_dia.py — Ajuda per a la PROVA MANUAL (Assemblea Bombers)
================================================================

Serveix per afegir un dia a mà a l'històric, a partir d'un Excel del TRI que
tinguis descarregat a l'ordinador. Útil per fer la prova de diversos dies sense
haver d'esperar l'automatisme diari.

Ús senzill (et pregunta el que necessita):
    python afegir_dia.py

Ús directe:
    python afegir_dia.py "Personal_de_guardia.xlsx" 2026-08-02

Després de fer-ho per als teus dies de prova, puja els canvis a GitHub:
    git add data/history.json data/latest.json
    git commit -m "Prova: dades de diversos dies"
    git push
"""
import sys, os, subprocess

def main():
    if len(sys.argv) >= 2:
        xlsx = sys.argv[1]
    else:
        xlsx = input("Arrossega aquí el fitxer Excel del TRI (o escriu-ne el nom) i prem Enter:\n> ").strip().strip('"').strip("'")
    if not os.path.exists(xlsx):
        print(f"\nNo trobo el fitxer: {xlsx}")
        print("Assegura't que el nom és correcte i que és a la mateixa carpeta, o arrossega'l a la finestra.")
        input("\nPrem Enter per sortir.")
        return

    if len(sys.argv) >= 3:
        data = sys.argv[2]
    else:
        data = input("\nQuina data té aquest TRI? (format AAAA-MM-DD, o deixa-ho buit per usar la data de l'Excel):\n> ").strip()

    script = os.path.join(os.path.dirname(__file__), "parse_tri.py")
    cmd = [sys.executable, script, "--input", xlsx]
    if data:
        cmd += ["--date", data]

    print("\nProcessant…\n")
    subprocess.run(cmd)
    print("\nFet! Si tot ha anat bé, la data ja és a data/history.json.")
    print("Pots repetir aquest pas per a cada dia de la prova.")
    input("\nPrem Enter per sortir.")

if __name__ == "__main__":
    main()
