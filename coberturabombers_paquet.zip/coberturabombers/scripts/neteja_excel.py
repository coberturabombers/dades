#!/usr/bin/env python3
"""
neteja_excel.py — Genera una còpia NETA de l'Excel del TRI (Assemblea Bombers)
==============================================================================

Agafa l'Excel complet "Personal de guàrdia" i en fa una còpia que NOMÉS conté les
dades de cobertura (parc, mínim de torn, efectius reals) de les 7 regions.

Tota la resta d'informació (comandaments, menús, vehicles, serveis, altres fulls...)
NO es copia. Així el fitxer que pugis al núvol no exposa res sensible.

Ús (et pregunta el fitxer si no li'n dones cap):
    python neteja_excel.py "Personal de guàrdia.xlsx"

Genera:  cobertura_neta.xlsx   (aquest és el que has de pujar al Drive)
"""

import sys
import os

try:
    import openpyxl
except ImportError:
    print("ERROR: cal instal·lar openpyxl  ->  pip install openpyxl", file=sys.stderr)
    sys.exit(1)

REGION_START_COLS = {2: "REC", 14: "REG", 26: "REMN", 38: "REL",
                     50: "REMS", 62: "RET", 74: "RETE"}


def main():
    if len(sys.argv) >= 2:
        src = sys.argv[1]
    else:
        src = input("Arrossega aquí l'Excel complet i prem Enter:\n> ").strip().strip('"').strip("'")

    if not os.path.exists(src):
        print(f"No trobo el fitxer: {src}")
        input("Prem Enter per sortir.")
        return

    wb = openpyxl.load_workbook(src, data_only=True)
    ws = wb["Dades"]

    # Nou llibre net, amb un sol full "Dades" que replica NOMÉS les columnes de cobertura
    out = openpyxl.Workbook()
    ods = out.active
    ods.title = "Dades"

    # Copiem, per cada regió, les columnes PARC / MÍNIM TORN / REALS A PARC,
    # mantenint les mateixes posicions de columna que l'original (perquè el parser
    # ja les coneix). La resta de columnes queden buides.
    for start_col, region in REGION_START_COLS.items():
        # fila 2 = nom regió, fila 3 = capçaleres (les repliquem)
        ods.cell(row=2, column=start_col, value=region)
        ods.cell(row=3, column=start_col, value="PARC")
        ods.cell(row=3, column=start_col + 1, value="MÍNIM TORN")
        ods.cell(row=3, column=start_col + 2, value="REALS A PARC")
        for r in range(4, 60):
            parc = ws.cell(row=r, column=start_col).value
            mn = ws.cell(row=r, column=start_col + 1).value
            rl = ws.cell(row=r, column=start_col + 2).value
            if parc is not None:
                ods.cell(row=r, column=start_col, value=parc)
            if mn is not None:
                ods.cell(row=r, column=start_col + 1, value=mn)
            if rl is not None:
                ods.cell(row=r, column=start_col + 2, value=rl)

    # Copiem també el full "Resum" NOMÉS amb la data (cel·la B4), sense la resta,
    # perquè el parser pugui llegir la data del dia.
    try:
        src_resum = wb["Resum"]
        ores = out.create_sheet("Resum")
        ores.cell(row=2, column=2, value="DATA")
        ores.cell(row=4, column=2, value=src_resum.cell(row=4, column=2).value)
    except Exception:
        pass

    dest = os.path.join(os.path.dirname(src) or ".", "cobertura_neta.xlsx")
    out.save(dest)
    print(f"\nFet! Còpia neta desada a:\n  {dest}\n")
    print("Aquest és el fitxer que has de pujar al Drive. NO conté cap dada sensible,")
    print("només parc / mínim / reals de cada regió.")
    input("\nPrem Enter per sortir.")


if __name__ == "__main__":
    main()
